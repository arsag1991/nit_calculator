package com.example.company.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.company.myapplication.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.coroutines.EmptyCoroutineContext.plus

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bPlus.setOnClickListener{
            fun plus (v: View){
                var result =  answer.text.toString().toInt()
                  if (edName1.text.isNotEmpty() && edName2.text.isNotEmpty()){
                      result = edName1.text.toString().toInt() + edName2.text.toString().toInt()
                  } else {Toast.makeText(applicationContext, "Error", Toast.LENGTH_LONG)}
        }



        /*inus.setOnClickListener {answer.text = edName1.text - edName1.text}

        bMult.setOnClickListener {answer.text = edName1.text.toString() * edName1.text.toString()}

        bDiv.setOnClickListener {answer.text = edName1.text.toString() / edName1.text.toString()}*/

    }



}
}